package com.example.demo.servicio;

import org.springframework.security.core.userdetails.UserDetailsService;

import com.example.demo.dto.UsuarioRegistroDTO;
import com.example.demo.modelo.Usuario;

import antlr.collections.List;

public interface UsuarioServicio extends UserDetailsService{

	public Usuario save(UsuarioRegistroDTO registroDTO);
	
	
}
