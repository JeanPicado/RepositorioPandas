package com.example.demo.contralador;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.example.demo.dto.UsuarioRegistroDTO;
import com.example.demo.servicio.UsuarioServicio;

@Controller
@RequestMapping("/registro")
public class Controlador {

	
	private UsuarioServicio usuarioServicio;
		
	
	public Controlador(UsuarioServicio usuarioServicio) {
		super();
		this.usuarioServicio = usuarioServicio;
	}

	@ModelAttribute("usuario")
	public UsuarioRegistroDTO retornarNuevoUsuarioRegistroDTO() {
		return new UsuarioRegistroDTO();
	}
	
	
	
	
	
	@GetMapping
	public String mostrarFormularioDeRegistro() {
		return "registro";
	}
	
	@PostMapping
	public String registrarCuentaDeUsuario(@ModelAttribute("usuario") UsuarioRegistroDTO registroDTO) {
		System.out.println("nobre regis " + registroDTO.getNombre());
		usuarioServicio.save(registroDTO);
		return "redirect:/registro?Exito";

	}
	
	
	
	
	
	
	
	
}
