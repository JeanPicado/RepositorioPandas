package com.example.demo.contralador;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class RegistroControlador {
	
	
	
	@GetMapping({"/","/login"})
	public String index() {
		return "login";
	}

	@GetMapping("/")
	public String verPaginaDeInicio() {
		
		return "index";
	}
}
	

